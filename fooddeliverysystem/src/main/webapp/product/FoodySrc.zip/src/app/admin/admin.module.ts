import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductListComponent } from './product-list/product-list.component';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule , ReactiveFormsModule }   from '@angular/forms';
import {MatTabsModule} from '@angular/material/tabs';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { AllUsersComponent } from './all-users/all-users.component';



@NgModule({
  declarations: [ProductListComponent, AllUsersComponent],
  imports: [
    CommonModule,
    MatTabsModule,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    AngularFontAwesomeModule
  ]
})
export class AdminModule { }
