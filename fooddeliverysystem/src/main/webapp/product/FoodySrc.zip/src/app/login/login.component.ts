import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../services/authentication.service';
import { DbServiceService } from 'src/services/db-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  errorMsg: String;
  showError: boolean

  constructor(
    private router: Router,
    private authService: AuthenticationService,
    private dbServiceService: DbServiceService
  ) { }

  ngOnInit() {
  }


  onMySubmit(inputData) {
    this.dbServiceService.getAllUsers().subscribe(
      data => {
        let userData: any
        userData = data;
        console.log(data);
        userData.forEach(element => {
          if(element.email === inputData.userName && element.password === inputData.password){
            inputData.role = element.role;
            inputData.firstName = element.firstName;
            sessionStorage.setItem('userDetails',JSON.stringify(inputData));
            if(element.role === 'ADMIN') {
              this.router.navigate(['products']);
            } else {
              this.router.navigate(['dashboard']);
            }
          }else {
            this.showError = true;
            this.errorMsg = "Invalid Details. Please check Username & Password";
          }
        });

      }, error => {
        console.log(error);
      }
    )
  }

  


}
