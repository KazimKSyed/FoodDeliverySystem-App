import { Component, OnInit } from '@angular/core';
import { DbServiceService } from './../../services/db-service.service';

export class myCartObj {
  public id: number;
  public categoryId: number;
  public itemName: String;
  public price: number;
  public count: number;
}
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  categoryList: object;
  Itemlistnew: {};
  myCart = [];
  newCount: number
  Subtotal = 0;
  msg: string
  showMsg: boolean;
  upcount =[];
  jsonData = []
  Itemlist = [];
   
  constructor(private dbService: DbServiceService) {  }

  ngOnInit() {
    debugger
    this.dbService.getCategory().subscribe(result => {
      this.getCatList(result);});
      this.dbService.getAllProduct().subscribe(result => {
        this.getItemList(result);})
    

  }
  getItemList(data){
    this.Itemlist =data;
    
    // this.Itemlist = [
    //   { id: 1, categoryId: 2, name: 'Apple', unitPrice: 100,imgSrc:"../../assets/apples.jpg" },
    //   { id: 2, categoryId: 2, name: 'Mango', unitPrice: 400 ,imgSrc:"../../assets/mango.jpg"  },
    //   { id: 3, categoryId: 2, name: 'Banana', unitPrice: 40 ,imgSrc:"../../assets/banana.jpg" },
  
    
   
    this.Itemlist.filter(items =>{
      items['isAdded']=true;
      items['imgSrc'] ="../../assets/milk1.jpg"   ;
      
     })
  }
  getCatList(result) {
    this.categoryList = result;
  }

  setIsAdded(data,flag){
    this.Itemlist.filter(items =>{
      if(items.id == data.id)
      items['isAdded']=flag;
    });
  }
  addList(data, count) {
    let notInlist = false;
    let totalCount = 0;
    this.setIsAdded(data,false);
    
    if (this.myCart.length == 0) {
      notInlist = true;
    }
    else {
      for (let i = 0; i < this.myCart.length; i++) {
        if (this.myCart[i].id != data.id) {
          notInlist = true;
        }
        else {
          notInlist = false;
          this.myCart[i].count = count;
          this.myCart[i].totalAmt = count * data.unitPrice
          break;
        }
      }
    }

    if (notInlist) {
      let newObj = {
        id: data.id,
        categoryId: data.categoryId,
        name: data.name,
        unitPrice: data.unitPrice,
        count: count,
        totalAmt: count * data.unitPrice,
        imgSrc : data.imgSrc
      }
      this.myCart.push(newObj);
      this.showMsg = true;
      this.msg = "Item added into list";

      setTimeout(()=>{   
            this.showMsg = false;
            this.msg = "";
        }, 3000);

     }
     this.newCount  = count;
    
     this.upcount[data.id]= this.newCount;

     this.setCartData();

    
  }

  countAction(data, type) {

    this.myCart.filter(items => {
      if (items.id == data.id) {
          if (type == 'Add') {
            this.newCount = parseInt(items.count) + 1;
          }
          else {
            this.newCount = parseInt(items.count) - 1;
          }
          items.count = this.newCount;
          items.totalAmt = this.newCount * data.unitPrice

          this.upcount[data.id]= this.newCount

          if(this.newCount < 1){
              this.setIsAdded(data,true);
              let index = this.myCart.findIndex(items => items.count ==0);
              this.myCart.splice(index,1);
          }

       
        }
   });
   localStorage.removeItem('myCart');
   this.setCartData();
   
  }
  setCartData(){
    localStorage.setItem('myCart', JSON.stringify(this.myCart));
 
  }
  calculate() {
    this.myCart.filter(items => {
      this.Subtotal = items.totalAmt + this.Subtotal
    });
   }

  onChange(deviceValue) {

    this.dbService.getAllProduct().subscribe(result => {
      this.getItemList(result);});

    if(deviceValue != ""){
      this.Itemlist = this.Itemlist.filter(items => {
        if (items.categoryId == deviceValue) {
         return items;
          }
        });
    }
   }

}
