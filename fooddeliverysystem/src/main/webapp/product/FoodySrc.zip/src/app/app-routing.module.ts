import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { OurServicesComponent } from './our-services/our-services.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { ItemListComponent } from './item-list/item-list.component';
import { HomeComponent } from './home/home.component';
import { LogoutComponent } from './logout/logout.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { RegistrationComponent } from './registration/registration.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { CheckoutComponent } from './checkout/checkout.component';
import {ProductListComponent} from './admin/product-list/product-list.component'
import{AllUsersComponent} from './admin/all-users/all-users.component'
const routes: Routes = [
  { path: '', redirectTo: '/welcome', pathMatch: 'full' },
  { path: 'about', component: AboutUsComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'our-services', component: OurServicesComponent },
  { path: 'login', component: LoginComponent },
  { path: 'itemList', component: ItemListComponent },
  { path: 'welcome', component: HomeComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'change-password', component: ChangePasswordComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'checkout',component: CheckoutComponent},
  { path: 'products', component: ProductListComponent },
  { path: 'users',component: AllUsersComponent},
  { path: '**', component: PageNotFoundComponent },

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],

exports: [RouterModule]
})
export class AppRoutingModule { }
