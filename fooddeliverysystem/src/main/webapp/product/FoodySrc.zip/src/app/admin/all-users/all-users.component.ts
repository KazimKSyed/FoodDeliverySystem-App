import { Component, OnInit } from '@angular/core';
import { DbServiceService } from 'src/services/db-service.service';

@Component({
  selector: 'app-all-users',
  templateUrl: './all-users.component.html',
  styleUrls: ['./all-users.component.css']
})
export class AllUsersComponent implements OnInit {
  allUsers =[];
  constructor(private dbServiceService : DbServiceService) { }

  ngOnInit() {
    this.dbServiceService.getAllUsers().subscribe(result => {
      this.getAllUser(result);
    });
}

  getAllUser(result){
    this.allUsers =result;
  }
}
