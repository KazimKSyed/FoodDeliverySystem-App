import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { DbServiceService } from '../../../services/db-service.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  productObj =[{id:1,categoryId:1,name:'Apple',unitPrice:30,imgSrc:"../../assest"}];
  categoryList: object;
  actionType ="Add";
  deletedMsg : boolean
  addProdForm = new FormGroup({
    categoryId: new FormControl(''),
    name: new FormControl(''),
    unitPrice: new FormControl(''),
    imgSrc: new FormControl(''),
    id : new FormControl('')
   
  });
  showMsg : boolean;
  msg : string
  constructor(private dbService : DbServiceService) { }

  ngOnInit() {
    
    this.dbService.getCategory().subscribe(result => {
      this.getCatList(result);});
    this.dbService.getAllProduct().subscribe(result => {
        this.getItemList(result);})
  }
  
  //Get Category list 
  getCatList(result) {
    this.categoryList = result;
  }

  getItemList(data){
    this.productObj =data;
    
    this.productObj.filter(items =>{
      items['imgSrc'] ="../../assets/milk1.jpg"   ;
      items['categoryId'] =1  ;
     })
  }


  //set form value on edit click
  editItem(data){
    this.addProdForm.setValue({  
      categoryId:data.categoryId,  
      name: data.name,  
      unitPrice: data.unitPrice,  
      imgSrc: data.imgSrc,  
      id : data.id
  });
  this.actionType = "Update";
  }

  //delete the item on click of delete
  deleteItem(id){
    this.productObj.splice(id,1);
    this.msg = "Product Deleted Suceessfully";
    this.deletedMsg= true;
    setTimeout( ()=>{
      this.deletedMsg =false;
      this.msg ="";
      },1000)
  }

  // Update or add product data 
  onSubmit() { 
    debugger;
    if( this.actionType == "Add"){
      this.productObj.push(this.addProdForm.value);
      this.msg = "Product Added Suceessfully";
    }
   else{
     let formData =this.addProdForm.value;
    this.productObj.filter(item => {
      if(item.id==formData.id){
        item.categoryId = formData.categoryId; 
        item.name= formData.name,  
        item.unitPrice= formData.unitPrice,  
        item.imgSrc= formData.imgSrc,  
        item.id = formData.id
      }
    })
    this.msg = "Product Updated Suceessfully";
   }
    this.showMsg =true;
  
    setTimeout( ()=>{
      this.showMsg =false;
      this.addProdForm.reset();
      var link = document.getElementById('closeModal');
      link.click();
      this.actionType = "Add";
      this.msg ="";
    },1000)

  }

}
