import { Component, OnInit, Input } from '@angular/core';
import { DbServiceService } from 'src/services/db-service.service';

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.css']
})
export class ItemListComponent implements OnInit {
  mycartData = [];
  total = 0
  emptyCart :boolean
  constructor(private dbServiceService : DbServiceService) { }

  ngOnInit() {
    this.mycartData = this.dbServiceService.getCartData('myCart');
    if(this.mycartData != null){
      this.emptyCart =false;
      this.updateTotalValue();
    }
    else  {
      this.emptyCart = true;
    }
  }

  //Update total price of cart items
  updateTotalValue(){
    this.total = 0
    this.mycartData.filter(items => {
      this.total = items.totalAmt + this.total;
    });
  }

  //Update list count 
  updateList(data,type){
    let newCount;
    this.mycartData.filter(items => {
      if (items.id == data.id) {
          if (type == 'Add') {
            newCount = parseInt(items.count) + 1;
          }
          else {
            newCount = parseInt(items.count) - 1;
          }
          items.count = newCount;
          items.totalAmt = newCount * data.unitPrice
          if(newCount < 1){
            let index = this.mycartData.findIndex(items => items.count ==0);
            this.mycartData.splice(index,1);
          }
      }
   });
   this.updateTotalValue();
  }

  //remove item from cart
  removeItem(id){
    let index = this.mycartData.findIndex(items => items.id ==id);
    this.mycartData.splice(index,1);
    this.dbServiceService.resetCartData(this.mycartData,'myCart');
    this.ngOnInit();
  }

}
