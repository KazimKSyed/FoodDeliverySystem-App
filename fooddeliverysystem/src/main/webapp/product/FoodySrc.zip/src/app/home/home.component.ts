import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/services/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  imagesUrl :any
  constructor(private authService : AuthenticationService,private router : Router) { }

  ngOnInit() {
    this.imagesUrl = [
      '../../assets/b1.jpg',
      '../../assets/b2.jpg',
      '../../assets/b3.jpg',
      '../../assets/b4.jpg',
      '../../assets/b5.jpg',
      '../../assets/b6.jpg',
      ];
  }
  exploreItems(type){
    if(this.authService.isLogin()){
      this.router.navigate(['dashboard']);
    }
    else{
      this.router.navigate(['login']);
    }
  }
}
