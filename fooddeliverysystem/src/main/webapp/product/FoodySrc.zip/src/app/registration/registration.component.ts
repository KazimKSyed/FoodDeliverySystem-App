import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { DbServiceService } from 'src/services/db-service.service';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registrionForm = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    email: new FormControl(''),
    password: new FormControl(''),
    passwordRepeat: new FormControl(''),
    contactNumber: new FormControl('')
   
  });
  showMsg : boolean;
  msg : string
  constructor(private router : Router,private dbService: DbServiceService) { }
 
  ngOnInit() {
  }
  onSubmit() {
   let userDetails = this.registrionForm.value;
   this.showMsg =true;
   this.msg = "User added Suceessfully";
    
    let data ={
    "firstName":userDetails.firstName,
    "lastName":userDetails.lastName,
    "email":userDetails.email,
    "contactNumber":userDetails.contactNumber,
    "role":"USER",
    "password":userDetails.password,
    "enabled":true,
    "confirmPassword":userDetails.password};


  this.dbService.addUser(data).subscribe(
        val => {
          setTimeout( ()=>{
            this.showMsg =false;
            this.router.navigate(['login']) ;
            },1000)
        });
    

  }
}
