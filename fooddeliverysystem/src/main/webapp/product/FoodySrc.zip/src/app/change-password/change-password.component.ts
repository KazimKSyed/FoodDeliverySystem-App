import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
 
  updatePasswordForm = new FormGroup({
    password: new FormControl(''),
   
  });
  showMsg : boolean
  updateSucc = "";
  constructor() { }

  ngOnInit() {
  }
  onSubmit() {
    // TODO: Use EventEmitter with form value
    console.warn(this.updatePasswordForm.value);
    this.showMsg =true;
    this.updateSucc = "Password Updated Suceessfully";

    setTimeout( ()=>{
    this.showMsg =false;
   
    },3000)

  }

}
