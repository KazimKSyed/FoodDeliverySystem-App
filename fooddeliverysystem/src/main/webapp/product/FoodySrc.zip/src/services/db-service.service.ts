import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export class userData {
  public  firstName : string;
  public lastName : string;
  public email : string;
  public contactNumber : string;
  public role : string;
  public password : string;
  public enabled : string;
  public confirmPassword : string;
}
@Injectable({
  providedIn: 'root'
})
export class DbServiceService {

  constructor(private httpClient : HttpClient) { }

  // Get all categories
  getCategory (){
    return this.httpClient.get("http://localhost:8081/category/");
  }
  
  //get all product list
  getAllProduct(){
    return this.httpClient.get("http://localhost:8081/product/");
 }

 // get cart data form localstorage
  getCartData(type){
    return JSON.parse(localStorage.getItem(type));
  }

  //reset cart data
  resetCartData(data,type){
    localStorage.removeItem(type);
    return localStorage.setItem(type,JSON.stringify(data));
  }

  //get all registred users
  getAllUsers(){
    return this.httpClient.get("http://localhost:8081/user/");
  }

  //add user
  addUser(data){
    return this.httpClient.post(" http://localhost:8081/user/",data);
  }

}
