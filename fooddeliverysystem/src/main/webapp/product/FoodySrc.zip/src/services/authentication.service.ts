import { Injectable } from '@angular/core';
import {DbServiceService} from './db-service.service'
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  flag :boolean
  constructor(private DbServiceService : DbServiceService) { }
 
  isAdmin(){
  let userDetails =  JSON.parse(sessionStorage.getItem('userDetails'));
    if(userDetails!= null && userDetails.role=='ADMIN'){
      return true;
    }
   
  }
  isLogin(){
    let userDetails =  JSON.parse(sessionStorage.getItem('userDetails'));
    if(userDetails!= null && userDetails.email !==null){
      return true;
    }
    
  }
  isLogout(){
    let userDetails =  JSON.parse(sessionStorage.getItem('userDetails'));
    if(userDetails == null){
      return true;
    }
    
  }
  getUserName(){
    let userDetails =  JSON.parse(sessionStorage.getItem('userDetails'));
    return userDetails.firstName;
    
  }
}
